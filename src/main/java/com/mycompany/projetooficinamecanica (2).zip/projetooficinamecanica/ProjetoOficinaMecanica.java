package com.mycompany.projetooficinamecanica;


import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

/**
 *
 * @author Lucas
 */
public class ProjetoOficinaMecanica {

    public static void main(String[] args) throws IOException {
        
    JsonUtil.carregarJsons();
        
    Menu.menuPrincipal();
       
       
      
       
    }
}
